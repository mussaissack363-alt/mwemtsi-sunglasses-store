---
name: mwemtsi eye wear
colors:
  surface: '#11131c'
  surface-dim: '#11131c'
  surface-bright: '#373943'
  surface-container-lowest: '#0c0e17'
  surface-container-low: '#191b24'
  surface-container: '#1d1f29'
  surface-container-high: '#282933'
  surface-container-highest: '#33343e'
  on-surface: '#e2e1ef'
  on-surface-variant: '#c4c5d9'
  inverse-surface: '#e2e1ef'
  inverse-on-surface: '#2e303a'
  outline: '#8e90a2'
  outline-variant: '#434656'
  surface-tint: '#b8c3ff'
  primary: '#b8c3ff'
  on-primary: '#002388'
  primary-container: '#2e5bff'
  on-primary-container: '#efefff'
  inverse-primary: '#124af0'
  secondary: '#cdc5bb'
  on-secondary: '#343029'
  secondary-container: '#4d4841'
  on-secondary-container: '#bfb7ad'
  tertiary: '#ffb59b'
  on-tertiary: '#5b1a00'
  tertiary-container: '#c24100'
  on-tertiary-container: '#ffece6'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dde1ff'
  primary-fixed-dim: '#b8c3ff'
  on-primary-fixed: '#001356'
  on-primary-fixed-variant: '#0035be'
  secondary-fixed: '#e9e1d7'
  secondary-fixed-dim: '#cdc5bb'
  on-secondary-fixed: '#1e1b15'
  on-secondary-fixed-variant: '#4b463f'
  tertiary-fixed: '#ffdbcf'
  tertiary-fixed-dim: '#ffb59b'
  on-tertiary-fixed: '#380d00'
  on-tertiary-fixed-variant: '#812800'
  background: '#11131c'
  on-background: '#e2e1ef'
  surface-variant: '#33343e'
  electric-cobalt: '#2E5BFF'
  deep-onyx: '#16130D'
  architectural-silver: '#D1C5B2'
  border-gray: '#2D2923'
typography:
  display-lg:
    fontFamily: Hanken Grotesk
    fontSize: 64px
    fontWeight: '300'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '400'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '400'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  title-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '500'
    lineHeight: '1.5'
    letterSpacing: 0.1em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0.01em
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.2em
spacing:
  base: 8px
  section-gap: 120px
  container-margin: 40px
  gutter: 24px
  grid-columns: '12'
---

## Brand & Style
The design system for **mwemtsi eye wear** centers on a high-precision, architectural aesthetic that treats eyewear as technical art. The brand personality is cold, sophisticated, and authoritative, targeting a clientele that appreciates engineering excellence and minimalist luxury.

The design style is **Minimalism** with a **Structural-Technical** edge. It utilizes a "blueprint" approach where layout hierarchy is defined by razor-sharp lines and high-contrast focal points rather than soft depth or shadows. The interface feels like a digital drafting table—deliberate, spacious, and uncompromisingly precise.

## Colors
The palette is dominated by a cinematic, deep-onyx environment. This near-black foundation allows product photography to stand out with dramatic clarity.

- **Primary (Electric Cobalt Blue):** This is the high-voltage signature of the brand. It is used exclusively for primary calls-to-action, active status indicators, hotspots, and critical highlights.
- **Secondary (Deep Onyx):** The structural core of the UI, providing a sophisticated, dark canvas.
- **Tertiary (Communication Green):** A functional color (#3DE273) reserved solely for customer service and WhatsApp triggers, ensuring it remains distinct from the brand’s cobalt highlights.
- **Neutrals:** Off-whites and muted silvers are used for text and metadata to ensure legibility without breaking the dark architectural mood.

## Typography
The typography system pairs the technical precision of **Hanken Grotesk** for headlines with the utilitarian clarity of **Inter** for functional text. 

A hallmark of this design system is the use of generous letter-spacing in titles and labels to evoke a sense of premium breathing room. Headlines are intentionally set in lighter weights (`300` or `400`) to maintain a sophisticated, non-aggressive presence. All functional UI labels must be set in uppercase via the `label-caps` style to distinguish navigation and meta-data from editorial content.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy with a structural, diagrammatic feel. Major sections are separated by 1px solid lines rather than whitespace alone, reinforcing the architectural aesthetic.

- **Desktop:** A 12-column grid with a massive 120px vertical rhythm between sections to emphasize exclusivity and focus.
- **Mobile:** A 4-column grid with 20px margins. Product displays utilize horizontal scrolling "shelves" to maintain a rigid, single-axis vertical scroll for the main page.
- **Alignment:** All elements must align to the left vertical axis of their grid column. Centered text is prohibited except for hero display moments.

## Elevation & Depth
This design system rejects shadows and blurs in favor of **Tonal Layering** and **High-Contrast Outlines**.

1. **Base Layer:** The deepest background (#16130D).
2. **Structural Layer:** Defined by 1px solid borders (#2D2923) that act as "grid lines."
3. **Priority Layer (Modals/Overlays):** These use a slightly lighter surface tint and must be capped with a 1px **Electric Cobalt** top border to signal active priority.

Visual hierarchy is communicated through line weight and the strategic application of the Cobalt blue accent against the dark base.

## Shapes
The shape language is strictly **Sharp (0px)**. 

Every UI element—buttons, input fields, image containers, and modals—must have 90-degree corners. This reinforces the narrative of precision engineering. Circular forms are strictly reserved for functional status indicators (like color swatches) to distinguish them from the structural elements of the interface.

## Components
- **Buttons:** Primary buttons are solid **Electric Cobalt Blue** with White text, featuring sharp corners. Secondary buttons are "Ghost" style with a 1px border in either White or Cobalt.
- **Input Fields:** Minimalist design with a bottom-border only (1px). On focus, the border and label transition to Cobalt Blue.
- **Cards:** Product cards are borderless, defined only by the image. Product details are appended below, separated by a thin 1px horizontal line.
- **Chips:** Sharp-edged rectangular boxes with a 1px border, used for sizing and material specifications.
- **WhatsApp Trigger:** A square (not round) floating box in the bottom right using the Tertiary Green. 
- **Navigation:** Top-tier navigation uses `label-caps`. Active states are indicated by a 2px **Electric Cobalt** underline that spans the width of the navigation item.
- **Hotspots:** Interactive product points are represented by a small Cobalt square that expands slightly on hover.